function UserAccountDetails() {
    return(
        <>
        this is a protected route if you are seeing this then you are a authorized user 😀
        </>
    )
}
export default UserAccountDetails;